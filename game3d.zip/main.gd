extends Node3D
## إله الخلق 3D (OmniForge 3D)

const SAVE_PATH := "user://omniforge3d_v1.json"
const LIFE := ["human", "animal", "plant", "fish"]
const ON_PLANET := ["human", "animal", "plant", "fish", "water", "earth", "fire"]

const ITEMS := {
	"universe": {"n": "كون", "p": 500.0},
	"galaxy": {"n": "مجرة", "p": 200.0},
	"solar": {"n": "نظام شمسي", "p": 80.0},
	"star": {"n": "نجم", "p": 40.0},
	"planet": {"n": "كوكب", "p": 25.0},
	"blackhole": {"n": "ثقب أسود", "p": 120.0},
	"human": {"n": "إنسان", "p": 10.0},
	"animal": {"n": "حيوان", "p": 6.0},
	"plant": {"n": "نبات", "p": 3.0},
	"fish": {"n": "سمكة", "p": 4.0},
	"water": {"n": "ماء", "p": 2.0},
	"earth": {"n": "أرض", "p": 3.0},
	"fire": {"n": "نار", "p": 5.0},
	"air": {"n": "هواء", "p": 2.0},
	"light": {"n": "نور", "p": 8.0},
}

# نصف القطر الأساسي لكل عنصر بوحدات العالم
const RAD := {
	"universe": 14.0, "galaxy": 8.0, "solar": 5.0, "star": 1.5, "planet": 1.3,
	"blackhole": 1.6, "human": 0.5, "animal": 0.55, "plant": 0.6, "fish": 0.4,
	"water": 0.7, "earth": 0.6, "fire": 0.5, "air": 0.5, "light": 0.5,
}
# ارتفاع مركز العنصر فوق مستوى الفضاء (كمضاعف لنصف القطر)
const HGT := {
	"universe": 0.0, "galaxy": 0.05, "solar": 0.1, "star": 1.3, "planet": 1.0,
	"blackhole": 1.0, "human": 0.0, "animal": 0.0, "plant": 0.0, "fish": 0.9,
	"water": 0.0, "earth": 0.0, "fire": 0.0, "air": 1.2, "light": 1.4,
}

const CATS := [
	{"n": "الكون", "k": ["universe", "galaxy", "solar", "star", "planet", "blackhole"]},
	{"n": "الحياة", "k": ["human", "animal", "plant", "fish"]},
	{"n": "العناصر", "k": ["water", "earth", "fire", "air", "light"]},
]

const SKILLS := [
	{"id": "create", "n": "قوة الخلق", "d": "تزيد قوة كل ما تخلقه 15% لكل مستوى"},
	{"id": "wrath", "n": "الغضب الإلهي", "d": "تزيد ضرر ضرباتك في المبارزة 12% لكل مستوى"},
	{"id": "shield", "n": "درع الأكوان", "d": "تقلل الضرر الذي تتلقاه 8% لكل مستوى"},
	{"id": "wisdom", "n": "حكمة الخلود", "d": "تقوّي الشفاء وتزيد الطاقة المستعادة"},
]

const GOD_DEFS := [
	{"n": "الحارس الأخضر", "kind": "verdant", "col": "#55e68a", "base": 600.0, "desc": "حكيم يداوي جراحه ويطيل المعركة"},
	{"n": "طاغية النجوم", "kind": "tyrant", "col": "#ff8a3d", "base": 1100.0, "desc": "عدواني يضرب بقوة نجمية مدمرة"},
	{"n": "سيد الفراغ", "kind": "void", "col": "#b46bff", "base": 1900.0, "desc": "ماكر يمتص طاقتك ويشفي نفسه"},
]

const P_ME := Vector3(-4.2, 1.7, 0.0)
const P_GOD := Vector3(4.2, 1.8, 0.0)

const GRID_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	vec2 q = wp.xz / 2.0;
	vec2 g = abs(fract(q - 0.5) - 0.5) / max(fwidth(q), vec2(0.0001));
	float line = 1.0 - min(min(g.x, g.y), 1.0);
	float d = length(wp.xz);
	float fade = clamp(1.0 - d / 80.0, 0.0, 1.0);
	ALBEDO = vec3(0.25, 0.4, 0.95) * line * fade * 0.6;
	ALPHA = 1.0;
}
"""

const PLANET_SHADER := """
shader_type spatial;
uniform vec4 c1 : source_color = vec4(0.1, 0.2, 0.5, 1.0);
uniform vec4 c2 : source_color = vec4(0.3, 0.7, 0.3, 1.0);
uniform float seed = 0.0;
varying vec3 op;
float h(vec3 p) { return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719)) + seed) * 43758.5453); }
float n(vec3 p) {
	vec3 i = floor(p);
	vec3 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = mix(mix(h(i), h(i + vec3(1.0, 0.0, 0.0)), f.x), mix(h(i + vec3(0.0, 1.0, 0.0)), h(i + vec3(1.0, 1.0, 0.0)), f.x), f.y);
	float b = mix(mix(h(i + vec3(0.0, 0.0, 1.0)), h(i + vec3(1.0, 0.0, 1.0)), f.x), mix(h(i + vec3(0.0, 1.0, 1.0)), h(i + vec3(1.0, 1.0, 1.0)), f.x), f.y);
	return mix(a, b, f.z);
}
void vertex() { op = normalize(VERTEX); }
void fragment() {
	vec3 p = op * 3.0;
	float v = n(p) * 0.6 + n(p * 2.0) * 0.3 + n(p * 4.0) * 0.1;
	float t = smoothstep(0.45, 0.58, v);
	ALBEDO = mix(c1.rgb, c2.rgb, t);
	ROUGHNESS = 0.9;
}
"""

# ---------- حالة اللعبة ----------
var data: Dictionary = {}
var ents: Array = []
var gods: Array = []
var screen := "menu"
var view := -1
var tool := "move"
var cat_idx := 0
var place_scale := 1.0
var tm := 0.0
var fnt: Font
var sfx := {}
var sfx_players: Array = []
var sfx_i := 0
var music: AudioStreamPlayer

# عالم ثلاثي الأبعاد
var cam: Camera3D
var stage: Node3D
var arena: Node3D
var duel_root: Node3D
var fx: Node3D
var nodes := {}
var anims: Array = []
var fxs: Array = []
var planet_shader: Shader
var yaw := 0.6
var pitch := 0.75
var dist := 15.0
var target := Vector3.ZERO

# واجهة
var hud: CanvasLayer
var hud_root: Control
var ui := {}
var lbl_power: Label
var xp_bar: ProgressBar
var lbl_hint: Label
var pal_box: HBoxContainer
var toast_lbl: Label
var tab_btns: Array = []
var bot_panel: PanelContainer
var skills_vb: VBoxContainer
var gods_vb: VBoxContainer
var res_lbl: Label
var war_lbl: Label
var visit_lbl: Label
var duel_log: Label
var duel_btns: Array = []
var bar_god: ProgressBar
var bar_me: ProgressBar
var bar_en: ProgressBar
var lbl_god: Label

# إدخال
var dragging := false
var drag_id := -1
var drag_off := Vector3.ZERO
var moved := false
var press_pos := Vector2.ZERO

# حرب العوالم
var units: Array = []
var war_god := -1
var war_t := 0.0
var war_over := false
var war_won := false
var war_speed := 1.0
var war_end_t := 0.0
var fp := 1.0
var fg := 1.0

# مبارزة
var dp := 100.0
var dpm := 100.0
var dg := 100.0
var dgm := 100.0
var en := 50.0
var g_en := 40.0
var p_shield := false
var g_shield := false
var turn := "player"
var log_lines: Array = []
var shake_p := 0.0
var shake_g := 0.0
var god_node: Node3D
var me_node: Node3D
var shield_me: MeshInstance3D
var shield_god: MeshInstance3D


class Proxy extends Control:
	signal tapped
	var cb: Callable
	var press_at := Vector2.ZERO

	func _ready() -> void:
		clip_contents = true

	func _draw() -> void:
		if cb.is_valid():
			cb.call(self)

	func _process(_d: float) -> void:
		if is_visible_in_tree():
			queue_redraw()

	func _gui_input(ev: InputEvent) -> void:
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed:
				press_at = ev.position
			else:
				if ev.position.distance_to(press_at) < 25.0:
					tapped.emit()


# ============================================================
#  البدء
# ============================================================
func _ready() -> void:
	randomize()
	setup_font()
	build_scene()
	setup_hud()
	setup_audio()
	build_ui()
	data = default_data()
	ents = data["ents"]
	gods = data["gods"]
	rebuild_world()
	go("menu")
	get_tree().create_timer(0.5).timeout.connect(start_music)


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if screen != "menu":
			save_game()


func vp() -> Vector2:
	return get_viewport().get_visible_rect().size


func setup_font() -> void:
	if ResourceLoader.exists("res://font.ttf"):
		fnt = load("res://font.ttf")
	else:
		var sf := SystemFont.new()
		sf.font_names = PackedStringArray(["Noto Sans Arabic", "Noto Naskh Arabic", "Roboto", "sans-serif"])
		fnt = sf


func mk_style(c: Color, r := 22, border := Color(1, 1, 1, 0.14)) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(r)
	s.border_color = border
	s.set_border_width_all(2)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


func setup_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	hud_root = Control.new()
	hud.add_child(hud_root)
	hud_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var th := Theme.new()
	th.default_font = fnt
	th.default_font_size = 36
	th.set_stylebox("normal", "Button", mk_style(Color(0.16, 0.12, 0.38, 0.96)))
	th.set_stylebox("hover", "Button", mk_style(Color(0.22, 0.17, 0.5, 0.96)))
	th.set_stylebox("pressed", "Button", mk_style(Color(0.3, 0.22, 0.65, 0.96)))
	th.set_stylebox("disabled", "Button", mk_style(Color(0.1, 0.1, 0.18, 0.8)))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_stylebox("panel", "PanelContainer", mk_style(Color(0.04, 0.03, 0.15, 0.9), 0, Color(0.5, 0.4, 1, 0.25)))
	th.set_color("font_color", "Button", Color.WHITE)
	th.set_color("font_hover_color", "Button", Color.WHITE)
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	th.set_color("font_disabled_color", "Button", Color(0.55, 0.55, 0.65))
	hud_root.theme = th


# ============================================================
#  بناء المشهد ثلاثي الأبعاد
# ============================================================
func build_scene() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.008, 0.008, 0.03)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.45, 0.5, 0.78)
	env.ambient_light_energy = 0.75
	env.glow_enabled = true
	env.glow_intensity = 0.8
	env.glow_bloom = 0.15
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55.0, -35.0, 0.0)
	sun.light_energy = 0.8
	add_child(sun)

	cam = Camera3D.new()
	cam.far = 1500.0
	cam.fov = 60.0
	add_child(cam)
	cam.current = true

	stage = Node3D.new()
	add_child(stage)
	arena = Node3D.new()
	add_child(arena)
	duel_root = Node3D.new()
	add_child(duel_root)
	fx = Node3D.new()
	add_child(fx)

	planet_shader = Shader.new()
	planet_shader.code = PLANET_SHADER
	build_starfield()
	build_grid()
	build_nebula(Color(0.45, 0.2, 0.9), Vector3(-160, 60, -200))
	build_nebula(Color(0.15, 0.4, 0.95), Vector3(180, -20, -150))
	build_nebula(Color(0.85, 0.25, 0.55), Vector3(40, 90, 220))


func build_starfield() -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.instance_count = 700
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 4
	sm.rings = 2
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	sm.material = m
	mm.mesh = sm
	for i in 700:
		var dir := Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized()
		var sc := randf_range(0.5, 1.8)
		mm.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3.ONE * sc), dir * randf_range(300.0, 500.0)))
		var c := Color(0.8, 0.85, 1.0).lerp(Color(1.0, 0.85, 0.7), randf())
		mm.set_instance_color(i, c)
	var inst := MultiMeshInstance3D.new()
	inst.multimesh = mm
	add_child(inst)


func build_grid() -> void:
	var sh := Shader.new()
	sh.code = GRID_SHADER
	var sm := ShaderMaterial.new()
	sm.shader = sh
	var pm := PlaneMesh.new()
	pm.size = Vector2(400, 400)
	var g := MeshInstance3D.new()
	g.mesh = pm
	g.material_override = sm
	g.position = Vector3(0, -0.02, 0)
	stage.add_child(g)
	g.set_meta("keep", true)


func build_nebula(c: Color, pos: Vector3) -> void:
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color(c.r, c.g, c.b, 0.45), Color(c.r, c.g, c.b, 0.0)])
	grad.offsets = PackedFloat32Array([0.0, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = gt
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	var q := QuadMesh.new()
	q.size = Vector2(420, 420)
	var n := MeshInstance3D.new()
	n.mesh = q
	n.material_override = m
	n.position = pos
	add_child(n)


# ============================================================
#  أدوات المجسمات
# ============================================================
func mat(c: Color, emi := 0.0, alpha := 1.0, rough := 0.75) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(c.r, c.g, c.b, alpha)
	m.roughness = rough
	if emi > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emi
	if alpha < 0.99:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m


func mi(parent: Node3D, mesh: Mesh, m: Material, pos := Vector3.ZERO) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.mesh = mesh
	n.material_override = m
	n.position = pos
	parent.add_child(n)
	return n


func sph(parent: Node3D, r: float, m: Material, pos := Vector3.ZERO, segs := 20) -> MeshInstance3D:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = segs
	s.rings = maxi(segs / 2, 4)
	return mi(parent, s, m, pos)


func cyl(parent: Node3D, rt: float, rb: float, h: float, m: Material, pos := Vector3.ZERO) -> MeshInstance3D:
	var c := CylinderMesh.new()
	c.top_radius = rt
	c.bottom_radius = rb
	c.height = h
	c.radial_segments = 14
	c.rings = 1
	return mi(parent, c, m, pos)


func cap(parent: Node3D, rad: float, h: float, m: Material, pos := Vector3.ZERO) -> MeshInstance3D:
	var c := CapsuleMesh.new()
	c.radius = rad
	c.height = maxf(h, rad * 2.0 + 0.01)
	c.radial_segments = 12
	c.rings = 4
	return mi(parent, c, m, pos)


func box(parent: Node3D, sz: Vector3, m: Material, pos := Vector3.ZERO) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = sz
	return mi(parent, b, m, pos)


func tor(parent: Node3D, inner: float, outer: float, m: Material, pos := Vector3.ZERO, segs := 32) -> MeshInstance3D:
	var t := TorusMesh.new()
	t.inner_radius = inner
	t.outer_radius = outer
	t.rings = segs
	t.ring_segments = 10
	return mi(parent, t, m, pos)


func omni(parent: Node3D, col: Color, energy: float, rng: float, pos := Vector3.ZERO) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.light_color = col
	l.light_energy = energy
	l.omni_range = rng
	l.position = pos
	parent.add_child(l)
	return l


func make_points(parent: Node3D, pos: PackedVector3Array, cols: PackedColorArray, pr: float) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.instance_count = pos.size()
	var sm := SphereMesh.new()
	sm.radius = pr
	sm.height = pr * 2.0
	sm.radial_segments = 4
	sm.rings = 2
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	sm.material = m
	mm.mesh = sm
	for i in pos.size():
		mm.set_instance_transform(i, Transform3D(Basis.IDENTITY, pos[i]))
		mm.set_instance_color(i, cols[i])
	var inst := MultiMeshInstance3D.new()
	inst.multimesh = mm
	parent.add_child(inst)


# ============================================================
#  بناء العناصر (كل عنصر مجسم ثلاثي الأبعاد)
# ============================================================
func build_ent(k: String, sd: float) -> Node3D:
	var root := Node3D.new()
	var r: float = RAD[k]
	match k:
		"universe":
			var bub := sph(root, r, mat(Color(0.5, 0.35, 1.0), 0.6, 0.1), Vector3.ZERO, 32)
			(bub.material_override as StandardMaterial3D).cull_mode = BaseMaterial3D.CULL_DISABLED
			sph(root, r * 0.3, mat(Color(0.6, 0.4, 1.0), 1.5, 0.12), Vector3.ZERO, 16)
			var P := PackedVector3Array()
			var C := PackedColorArray()
			for i in 90:
				var d := Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized() * r * randf_range(0.2, 0.92)
				P.append(d)
				C.append(Color(0.75, 0.8, 1.0).lerp(Color(1, 0.8, 0.9), randf()))
			make_points(root, P, C, r * 0.012)
			root.set_meta("a", "spin")
			root.set_meta("sp", 0.04)
		"galaxy":
			var P := PackedVector3Array()
			var C := PackedColorArray()
			for i in 420:
				var arm := i % 2
				var f := pow(randf(), 0.6)
				var ang := f * 5.5 + float(arm) * PI + randf_range(-0.25, 0.25) * (1.2 - f)
				P.append(Vector3(cos(ang) * f * r, randf_range(-0.05, 0.05) * r * (1.0 - f), sin(ang) * f * r))
				C.append(Color(0.5, 0.65, 1.0).lerp(Color(1.0, 0.85, 0.5), 1.0 - f))
			make_points(root, P, C, r * 0.022)
			sph(root, r * 0.12, mat(Color(1, 0.9, 0.6), 3.0), Vector3.ZERO, 12)
			sph(root, r * 0.28, mat(Color(1, 0.85, 0.5), 1.2, 0.18), Vector3.ZERO, 12)
			root.set_meta("a", "spin")
			root.set_meta("sp", 0.25)
		"solar":
			sph(root, r * 0.14, mat(Color(1, 0.85, 0.3), 3.0), Vector3.ZERO, 16)
			omni(root, Color(1, 0.9, 0.6), 1.5, r * 6.0)
			var pcols := [Color(0.4, 0.7, 1), Color(1, 0.5, 0.4), Color(0.6, 1, 0.6)]
			var pivots: Array = []
			for i in 3:
				var dd := r * (0.35 + 0.28 * float(i))
				tor(root, dd - r * 0.006, dd + r * 0.006, mat(Color(1, 1, 1), 0.6, 0.35), Vector3.ZERO, 48)
				var pv := Node3D.new()
				root.add_child(pv)
				pv.rotation.y = randf() * TAU
				sph(pv, r * 0.045, mat(pcols[i]), Vector3(dd, 0, 0), 12)
				pivots.append(pv)
			root.set_meta("a", "solar")
			root.set_meta("pv", pivots)
		"star":
			sph(root, r, mat(Color(1, 0.9, 0.5), 3.5), Vector3.ZERO, 24)
			var cor := sph(root, r * 1.3, mat(Color(1, 0.8, 0.3), 1.5, 0.22), Vector3.ZERO, 16)
			sph(root, r * 1.8, mat(Color(1, 0.6, 0.2), 1.0, 0.08), Vector3.ZERO, 12)
			omni(root, Color(1, 0.9, 0.6), 2.2, r * 25.0)
			root.set_meta("a", "pulse")
			root.set_meta("cor", cor)
		"planet":
			var body := Node3D.new()
			root.add_child(body)
			root.set_meta("body", body)
			var sm := ShaderMaterial.new()
			sm.shader = planet_shader
			var h := fmod(sd * 2.7, 1.0)
			sm.set_shader_parameter("c1", Color.from_hsv(h, 0.6, 0.55))
			sm.set_shader_parameter("c2", Color.from_hsv(fmod(h + 0.18, 1.0), 0.5, 0.95))
			sm.set_shader_parameter("seed", sd * 50.0)
			sph(body, r, sm, Vector3.ZERO, 32)
			sph(root, r * 1.07, mat(Color.from_hsv(h, 0.3, 1.0), 0.5, 0.14), Vector3.ZERO, 20)
			if sd > 0.6:
				var rg := tor(root, r * 1.4, r * 1.9, mat(Color(0.9, 0.85, 0.7), 0.2, 0.7), Vector3.ZERO, 40)
				rg.scale = Vector3(1, 0.04, 1)
				rg.rotation.x = 0.4
			root.rotation.z = 0.3
			root.set_meta("a", "planet")
		"blackhole":
			var bm := StandardMaterial3D.new()
			bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			bm.albedo_color = Color.BLACK
			sph(root, r, bm, Vector3.ZERO, 28)
			var d1 := tor(root, r * 1.25, r * 2.8, mat(Color(1, 0.5, 0.15), 2.2, 0.85), Vector3.ZERO, 48)
			d1.scale = Vector3(1, 0.05, 1)
			var d2 := tor(root, r * 1.1, r * 1.6, mat(Color(1, 0.9, 0.6), 3.0, 0.9), Vector3.ZERO, 40)
			d2.scale = Vector3(1, 0.04, 1)
			var ph := tor(root, r * 1.02, r * 1.1, mat(Color(1, 0.95, 0.8), 3.0), Vector3.ZERO, 40)
			ph.rotation.x = 1.25
			root.rotation.z = 0.25
			root.set_meta("a", "bh")
			root.set_meta("d1", d1)
			root.set_meta("d2", d2)
		"human":
			var m := Node3D.new()
			root.add_child(m)
			root.set_meta("m", m)
			var shirt := Color.from_hsv(fmod(sd * 3.0, 1.0), 0.6, 0.9)
			var skin := Color(1, 0.82, 0.68)
			var pants := Color(0.25, 0.28, 0.55)
			cyl(m, r * 0.09, r * 0.09, r * 0.55, mat(pants), Vector3(-r * 0.13, r * 0.28, 0))
			cyl(m, r * 0.09, r * 0.09, r * 0.55, mat(pants), Vector3(r * 0.13, r * 0.28, 0))
			cap(m, r * 0.24, r * 0.8, mat(shirt), Vector3(0, r * 0.95, 0))
			var a1 := cyl(m, r * 0.07, r * 0.07, r * 0.6, mat(skin), Vector3(-r * 0.36, r * 0.95, 0))
			a1.rotation.z = 0.25
			var a2 := cyl(m, r * 0.07, r * 0.07, r * 0.6, mat(skin), Vector3(r * 0.36, r * 0.95, 0))
			a2.rotation.z = -0.25
			sph(m, r * 0.22, mat(skin), Vector3(0, r * 1.55, 0), 14)
			sph(m, r * 0.04, mat(Color.BLACK), Vector3(-r * 0.08, r * 1.58, r * 0.2), 6)
			sph(m, r * 0.04, mat(Color.BLACK), Vector3(r * 0.08, r * 1.58, r * 0.2), 6)
			root.set_meta("a", "life")
		"animal":
			var m := Node3D.new()
			root.add_child(m)
			root.set_meta("m", m)
			var col := Color.from_hsv(0.06 + fmod(sd, 0.1), 0.55, 0.72)
			var b := sph(m, r * 0.5, mat(col), Vector3(0, r * 0.7, 0), 14)
			b.scale = Vector3(0.9, 0.75, 1.5)
			for i in 4:
				var lx: float = -r * 0.22 if i % 2 == 0 else r * 0.22
				var lz: float = -r * 0.45 if i < 2 else r * 0.45
				cyl(m, r * 0.07, r * 0.06, r * 0.5, mat(col.darkened(0.3)), Vector3(lx, r * 0.25, lz))
			sph(m, r * 0.26, mat(col.lightened(0.1)), Vector3(0, r * 0.95, r * 0.85), 12)
			cyl(m, 0.0, r * 0.08, r * 0.2, mat(col.darkened(0.2)), Vector3(-r * 0.12, r * 1.2, r * 0.8))
			cyl(m, 0.0, r * 0.08, r * 0.2, mat(col.darkened(0.2)), Vector3(r * 0.12, r * 1.2, r * 0.8))
			sph(m, r * 0.04, mat(Color.BLACK), Vector3(-r * 0.1, r * 1.0, r * 1.07), 6)
			sph(m, r * 0.04, mat(Color.BLACK), Vector3(r * 0.1, r * 1.0, r * 1.07), 6)
			var tail := cyl(m, r * 0.04, r * 0.07, r * 0.45, mat(col), Vector3(0, r * 0.85, -r * 0.8))
			tail.rotation.x = -0.9
			root.set_meta("a", "life")
		"plant":
			var m := Node3D.new()
			root.add_child(m)
			root.set_meta("m", m)
			cyl(m, r * 0.06, r * 0.1, r * 0.8, mat(Color(0.45, 0.3, 0.15)), Vector3(0, r * 0.4, 0))
			cyl(m, 0.0, r * 0.55, r * 0.7, mat(Color(0.2, 0.65, 0.3)), Vector3(0, r * 0.95, 0))
			cyl(m, 0.0, r * 0.4, r * 0.6, mat(Color(0.25, 0.75, 0.35)), Vector3(0, r * 1.35, 0))
			sph(m, r * 0.1, mat(Color(1, 0.5, 0.7), 0.8), Vector3(r * 0.3, r * 0.75, r * 0.2), 8)
			sph(m, r * 0.1, mat(Color(1, 0.9, 0.3), 0.8), Vector3(-r * 0.25, r * 0.65, -r * 0.25), 8)
			root.set_meta("a", "life")
		"fish":
			var m := Node3D.new()
			root.add_child(m)
			root.set_meta("m", m)
			var col := Color.from_hsv(fmod(0.05 + sd * 0.6, 1.0), 0.7, 1.0)
			var b := sph(m, r * 0.5, mat(col, 0.3), Vector3.ZERO, 14)
			b.scale = Vector3(0.55, 0.6, 1.4)
			var tl := cyl(m, 0.0, r * 0.35, r * 0.5, mat(col.darkened(0.15), 0.3), Vector3(0, 0, -r * 0.85))
			tl.rotation.x = PI * 0.5
			var fn := cyl(m, 0.0, r * 0.2, r * 0.4, mat(col.darkened(0.2), 0.3), Vector3(0, r * 0.4, -r * 0.1))
			fn.rotation.x = -0.4
			sph(m, r * 0.08, mat(Color.WHITE), Vector3(-r * 0.2, r * 0.1, r * 0.45), 8)
			sph(m, r * 0.08, mat(Color.WHITE), Vector3(r * 0.2, r * 0.1, r * 0.45), 8)
			sph(m, r * 0.04, mat(Color.BLACK), Vector3(-r * 0.22, r * 0.1, r * 0.5), 6)
			sph(m, r * 0.04, mat(Color.BLACK), Vector3(r * 0.22, r * 0.1, r * 0.5), 6)
			root.set_meta("a", "life")
		"water":
			cyl(root, r, r, r * 0.12, mat(Color(0.2, 0.55, 1.0), 0.6, 0.75, 0.2), Vector3(0, r * 0.06, 0))
			var rp := tor(root, r * 0.6, r * 0.66, mat(Color(0.8, 0.95, 1.0), 1.0, 0.6), Vector3(0, r * 0.13, 0), 24)
			rp.scale = Vector3(1, 0.5, 1)
			root.set_meta("a", "water")
			root.set_meta("rp", rp)
		"earth":
			var rk := Color(0.45, 0.32, 0.2)
			var b1 := sph(root, r * 0.7, mat(rk, 0.0, 1.0, 1.0), Vector3(0, r * 0.3, 0), 10)
			b1.scale = Vector3(1, 0.6, 1)
			var b2 := sph(root, r * 0.45, mat(rk.darkened(0.1), 0.0, 1.0, 1.0), Vector3(r * 0.55, r * 0.15, r * 0.2), 10)
			b2.scale = Vector3(1, 0.7, 1)
			var cp := sph(root, r * 0.55, mat(Color(0.3, 0.7, 0.3), 0.0, 1.0, 1.0), Vector3(0, r * 0.45, 0), 10)
			cp.scale = Vector3(1, 0.35, 1)
		"fire":
			var fl := Node3D.new()
			root.add_child(fl)
			cyl(fl, 0.0, r * 0.55, r * 1.4, mat(Color(1, 0.35, 0.08), 2.5, 0.9), Vector3(0, r * 0.7, 0))
			cyl(fl, 0.0, r * 0.38, r * 1.0, mat(Color(1, 0.7, 0.15), 3.0, 0.95), Vector3(0, r * 0.55, 0))
			cyl(fl, 0.0, r * 0.2, r * 0.6, mat(Color(1, 0.95, 0.6), 3.5), Vector3(0, r * 0.35, 0))
			var lg := omni(root, Color(1, 0.55, 0.2), 1.5, r * 14.0, Vector3(0, r * 0.8, 0))
			root.set_meta("a", "fire")
			root.set_meta("fl", fl)
			root.set_meta("lg", lg)
		"air":
			var rings: Array = []
			for i in 3:
				var rr := r * (0.5 + 0.25 * float(i))
				var t := tor(root, rr - r * 0.03, rr + r * 0.03, mat(Color(0.85, 0.95, 1.0), 0.8, 0.5), Vector3(0, r * 0.3 * float(i) - r * 0.3, 0), 28)
				t.rotation.x = 0.3 * float(i)
				rings.append(t)
			root.set_meta("a", "air")
			root.set_meta("rings", rings)
		"light":
			sph(root, r * 0.5, mat(Color(1, 1, 0.85), 4.0), Vector3.ZERO, 14)
			sph(root, r * 1.1, mat(Color(1, 0.95, 0.5), 1.5, 0.12), Vector3.ZERO, 12)
			var rays := Node3D.new()
			root.add_child(rays)
			for i in 4:
				var ry := cyl(rays, r * 0.03, r * 0.03, r * 2.4, mat(Color(1, 0.95, 0.6), 2.5, 0.8))
				ry.rotation = Vector3(randf() * PI, randf() * PI, randf() * PI)
			omni(root, Color(1, 0.95, 0.7), 1.6, r * 16.0)
			root.set_meta("a", "light")
			root.set_meta("rays", rays)
	root.set_meta("sd", sd)
	return root


func build_minion(col: Color) -> Node3D:
	var root := Node3D.new()
	var m := Node3D.new()
	root.add_child(m)
	root.set_meta("m", m)
	sph(m, 0.55, mat(col.darkened(0.25), 0.4), Vector3(0, 0.6, 0), 14)
	var h1 := cyl(m, 0.0, 0.13, 0.5, mat(col.lightened(0.2), 0.6), Vector3(-0.28, 1.15, 0))
	h1.rotation.z = 0.35
	var h2 := cyl(m, 0.0, 0.13, 0.5, mat(col.lightened(0.2), 0.6), Vector3(0.28, 1.15, 0))
	h2.rotation.z = -0.35
	sph(m, 0.13, mat(Color.WHITE, 1.0), Vector3(-0.2, 0.75, 0.45), 8)
	sph(m, 0.13, mat(Color.WHITE, 1.0), Vector3(0.2, 0.75, 0.45), 8)
	sph(m, 0.06, mat(Color.BLACK), Vector3(-0.2, 0.75, 0.56), 6)
	sph(m, 0.06, mat(Color.BLACK), Vector3(0.2, 0.75, 0.56), 6)
	return root


func build_machine() -> Node3D:
	var root := Node3D.new()
	sph(root, 0.55, mat(Color(0.7, 0.95, 1.0), 3.0), Vector3.ZERO, 20)
	sph(root, 0.85, mat(Color(0.4, 0.7, 1.0), 1.2, 0.2), Vector3.ZERO, 16)
	var rings: Array = []
	var r1 := tor(root, 1.15, 1.25, mat(Color(0.6, 0.85, 1.0), 2.0), Vector3.ZERO, 40)
	var r2 := tor(root, 1.4, 1.48, mat(Color(0.5, 0.8, 1.0), 2.0), Vector3.ZERO, 40)
	r2.rotation.x = 1.0
	var r3 := tor(root, 1.65, 1.72, mat(Color(0.8, 0.9, 1.0), 2.0), Vector3.ZERO, 40)
	r3.rotation.z = 1.0
	rings.append(r1)
	rings.append(r2)
	rings.append(r3)
	omni(root, Color(0.6, 0.85, 1.0), 2.0, 14.0)
	root.set_meta("rings", rings)
	return root


func build_god(kind: String, col: Color) -> Node3D:
	var root := Node3D.new()
	var body := Node3D.new()
	root.add_child(body)
	body.rotation.y = -PI * 0.5
	sph(body, 1.1, mat(col.darkened(0.25), 0.5), Vector3.ZERO, 24)
	sph(body, 1.5, mat(col, 1.2, 0.15), Vector3.ZERO, 16)
	sph(body, 0.2, mat(Color.WHITE, 1.5), Vector3(-0.38, 0.2, 0.95), 10)
	sph(body, 0.2, mat(Color.WHITE, 1.5), Vector3(0.38, 0.2, 0.95), 10)
	sph(body, 0.1, mat(Color.BLACK), Vector3(-0.38, 0.2, 1.12), 8)
	sph(body, 0.1, mat(Color.BLACK), Vector3(0.38, 0.2, 1.12), 8)
	box(body, Vector3(0.6, 0.08, 0.1), mat(Color(0.05, 0.02, 0.05)), Vector3(0, -0.3, 1.05))
	match kind:
		"tyrant":
			var h1 := cyl(body, 0.0, 0.25, 1.1, mat(col.lightened(0.2), 1.5), Vector3(-0.6, 1.2, 0))
			h1.rotation.z = 0.4
			var h2 := cyl(body, 0.0, 0.25, 1.1, mat(col.lightened(0.2), 1.5), Vector3(0.6, 1.2, 0))
			h2.rotation.z = -0.4
		"verdant":
			var l1 := cyl(body, 0.0, 0.3, 1.0, mat(Color(0.5, 1, 0.6), 1.3), Vector3(-0.55, 1.2, 0))
			l1.rotation.z = 0.7
			var l2 := cyl(body, 0.0, 0.3, 1.0, mat(Color(0.5, 1, 0.6), 1.3), Vector3(0.55, 1.2, 0))
			l2.rotation.z = -0.7
		_:
			var hl := tor(body, 0.9, 1.0, mat(col.lightened(0.4), 2.0), Vector3(0, 1.5, 0), 32)
			hl.rotation.x = PI * 0.5
	var rings: Array = []
	var a1 := tor(root, 1.55, 1.63, mat(col.lightened(0.3), 2.0), Vector3.ZERO, 40)
	var a2 := tor(root, 1.85, 1.92, mat(col, 2.0), Vector3.ZERO, 40)
	a2.rotation.x = 1.1
	rings.append(a1)
	rings.append(a2)
	omni(root, col, 2.2, 14.0)
	root.set_meta("rings", rings)
	return root


# ============================================================
#  الصوت (يُولَّد بالكود)
# ============================================================
func mk_wav(samples: PackedFloat32Array, rate: int, loop := false) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		bytes.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = samples.size()
	return w


func tone(f0: float, f1: float, dur: float, vol: float, noise := 0.0) -> AudioStreamWAV:
	var rate := 22050
	var n := int(dur * rate)
	var s := PackedFloat32Array()
	s.resize(n)
	var ph := 0.0
	for i in n:
		var u := float(i) / float(n)
		var f := lerpf(f0, f1, u)
		ph += TAU * f / float(rate)
		var env := (1.0 - u) * (1.0 - u)
		if u < 0.02:
			env *= u / 0.02
		s[i] = (sin(ph) + noise * randf_range(-1.0, 1.0)) * env * vol
	return mk_wav(s, rate)


func setup_audio() -> void:
	sfx["click"] = tone(660.0, 880.0, 0.08, 0.35)
	sfx["place"] = tone(300.0, 900.0, 0.25, 0.4)
	sfx["erase"] = tone(400.0, 120.0, 0.2, 0.35, 0.3)
	sfx["hit"] = tone(180.0, 60.0, 0.18, 0.5, 0.5)
	sfx["big"] = tone(120.0, 40.0, 0.5, 0.6, 0.6)
	sfx["win"] = tone(400.0, 1200.0, 0.8, 0.4)
	sfx["lose"] = tone(300.0, 80.0, 0.9, 0.4)
	sfx["heal"] = tone(500.0, 1000.0, 0.4, 0.3)
	sfx["shoot"] = tone(900.0, 300.0, 0.3, 0.3)
	for i in 4:
		var p := AudioStreamPlayer.new()
		add_child(p)
		sfx_players.append(p)
	music = AudioStreamPlayer.new()
	music.volume_db = -13.0
	add_child(music)


func play(n: String) -> void:
	if not sfx.has(n):
		return
	var p: AudioStreamPlayer = sfx_players[sfx_i % 4]
	sfx_i += 1
	p.stream = sfx[n]
	p.play()


func start_music() -> void:
	var rate := 8000
	var secs := 16
	var n := rate * secs
	var s := PackedFloat32Array()
	s.resize(n)
	var chords := [
		[110.0, 165.0, 220.0, 330.0],
		[87.5, 130.5, 175.0, 262.0],
		[98.0, 147.0, 196.0, 294.0],
		[110.0, 165.0, 220.0, 277.0],
	]
	for i in n:
		var t := float(i) / float(rate)
		var chi := int(t / 4.0) % 4
		var u := fmod(t, 4.0) / 4.0
		var env := sin(PI * u)
		env *= env
		var v := 0.0
		var ch: Array = chords[chi]
		for j in 4:
			var f: float = ch[j]
			var amp: float = 0.5 if j < 2 else 0.3
			v += sin(TAU * f * t) * amp
		v *= env * 0.22
		var pt := fmod(t, 2.0)
		var pf: float = 660.0 if (int(t / 2.0) % 2) == 0 else 880.0
		v += sin(TAU * pf * t) * exp(-pt * 3.0) * 0.08
		s[i] = v
	music.stream = mk_wav(s, rate, true)
	music.play()


# ============================================================
#  البيانات والحفظ
# ============================================================
func new_id() -> int:
	data["next_id"] = int(data["next_id"]) + 1
	return int(data["next_id"])


func rand_normal() -> Vector3:
	var n := Vector3(randf_range(-1, 1), randf_range(-0.3, 1), randf_range(-1, 1))
	if n.length() < 0.1:
		n = Vector3.UP
	return n.normalized()


func make_god(i: int, tier: int) -> Dictionary:
	var df: Dictionary = GOD_DEFS[i % 3]
	var pw: float = float(df["base"]) * pow(1.6, float(tier))
	var nm: String = df["n"]
	if tier > 0:
		nm += " (الجيل %d)" % (tier + 1)
	var pool := ["star", "planet", "human", "animal", "plant", "fish", "water", "earth", "fire", "air", "light", "galaxy", "solar", "blackhole", "universe"]
	var list: Array = []
	var nid := 0
	var cnt := clampi(int(pw / 55.0), 10, 40)
	var spread := 6.0 + float(cnt) * 0.45
	var planet_ids: Array = []
	var np := 2 + randi() % 3
	for j in np:
		nid += 1
		planet_ids.append(nid)
		var a := randf() * TAU
		var dd := sqrt(randf()) * spread
		list.append({"id": nid, "k": "planet", "x": cos(a) * dd, "z": sin(a) * dd, "s": randf_range(1.0, 2.0), "seed": randf()})
	for j in cnt:
		nid += 1
		var k: String
		if randf() < 0.8:
			k = pool[randi() % 11]
		else:
			k = pool[11 + randi() % 4]
		var sc := randf_range(0.7, 1.5)
		if k == "universe" or k == "galaxy" or k == "solar":
			sc = randf_range(0.4, 0.7)
		if ON_PLANET.has(k):
			var pid: int = planet_ids[randi() % planet_ids.size()]
			var nr := rand_normal()
			list.append({"id": nid, "k": k, "on": pid, "nx": nr.x, "ny": nr.y, "nz": nr.z, "s": sc, "seed": randf()})
		else:
			var a := randf() * TAU
			var dd := sqrt(randf()) * spread
			list.append({"id": nid, "k": k, "x": cos(a) * dd, "z": sin(a) * dd, "s": sc, "seed": randf()})
	return {"i": i % 3, "n": nm, "kind": df["kind"], "col": df["col"], "desc": df["desc"], "power": pw, "ents": list}


func default_data() -> Dictionary:
	var starter: Array = [
		{"id": 1, "k": "star", "x": -7.0, "z": -5.0, "s": 1.5, "seed": 0.31},
		{"id": 2, "k": "planet", "x": 0.0, "z": 0.0, "s": 1.6, "seed": 0.62},
		{"id": 3, "k": "human", "on": 2, "nx": 0.1, "ny": 1.0, "nz": 0.2, "s": 1.0, "seed": 0.15},
		{"id": 4, "k": "plant", "on": 2, "nx": 0.8, "ny": 0.6, "nz": -0.2, "s": 1.0, "seed": 0.77},
		{"id": 5, "k": "fish", "x": 4.0, "z": 2.0, "s": 1.0, "seed": 0.44},
	]
	return {
		"level": 1, "xp": 0, "points": 0, "bonus": 0.0, "wins": 0, "next_id": 5,
		"skills": {"create": 0, "wrath": 0, "shield": 0, "wisdom": 0},
		"ents": starter,
		"gods": [make_god(0, 0), make_god(1, 0), make_god(2, 0)],
	}


func save_game() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))


func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var txt := FileAccess.get_file_as_string(SAVE_PATH)
	var j = JSON.parse_string(txt)
	if j is Dictionary and j.has("ents") and j.has("gods") and j.has("skills"):
		data = j
		for k in ["level", "xp", "points", "wins", "next_id"]:
			data[k] = int(data.get(k, 0))
		data["level"] = maxi(1, int(data["level"]))
		data["bonus"] = float(data.get("bonus", 0.0))
		for sk in ["create", "wrath", "shield", "wisdom"]:
			data["skills"][sk] = int(data["skills"].get(sk, 0))
		ents = data["ents"]
		gods = data["gods"]
		var mx := 0
		for e in ents:
			mx = maxi(mx, int(e["id"]))
		data["next_id"] = maxi(int(data["next_id"]), mx)
		return true
	return false


func skill(id: String) -> int:
	return int(data["skills"][id])


func xp_need() -> int:
	return 60 + 40 * int(data["level"])


func add_xp(n: int) -> void:
	data["xp"] = int(data["xp"]) + n
	while int(data["xp"]) >= xp_need():
		data["xp"] = int(data["xp"]) - xp_need()
		data["level"] = int(data["level"]) + 1
		data["points"] = int(data["points"]) + 1
		toast("ارتقيت إلى المستوى %d  |  نقطة مهارة جديدة" % int(data["level"]))
		play("win")


func player_power() -> float:
	var s: float = 50.0 + float(data["level"]) * 20.0 + float(data["bonus"])
	for e in ents:
		var k: String = e["k"]
		var p: float = ITEMS[k]["p"]
		s += p * sqrt(float(e["s"]))
	return s * (1.0 + 0.15 * float(skill("create")))


func count_life(arr: Array) -> int:
	var c := 0
	for e in arr:
		if LIFE.has(e["k"]):
			c += 1
	return c


func world_center(arr: Array) -> Vector3:
	var s := Vector3.ZERO
	var c := 0
	for e in arr:
		if not e.has("on"):
			s += Vector3(float(e["x"]), 0, float(e["z"]))
			c += 1
	if c == 0:
		return Vector3.ZERO
	return s / float(c)


func cur_ents() -> Array:
	if view < 0:
		return ents
	return gods[view]["ents"]


func find_ent(id: int) -> Dictionary:
	for e in cur_ents():
		if int(e["id"]) == id:
			return e
	return {}


# ============================================================
#  بناء العالم في المشهد
# ============================================================
func rebuild_world() -> void:
	for c in stage.get_children():
		if c.has_meta("keep"):
			continue
		stage.remove_child(c)
		c.queue_free()
	anims.clear()
	nodes.clear()
	var list := cur_ents()
	for e in list:
		if not e.has("on"):
			add_ent_node(e)
	for e in list:
		if e.has("on"):
			add_ent_node(e)


func add_ent_node(e: Dictionary) -> void:
	var k: String = e["k"]
	var s: float = e["s"]
	var n := build_ent(k, float(e["seed"]))
	n.set_meta("id", int(e["id"]))
	if e.has("on"):
		var par: Node3D = nodes.get(int(e["on"]))
		if par == null or not par.has_meta("body"):
			n.free()
			return
		var body: Node3D = par.get_meta("body")
		body.add_child(n)
		var nm := Vector3(float(e["nx"]), float(e["ny"]), float(e["nz"])).normalized()
		var ref: Vector3 = Vector3.FORWARD if absf(nm.dot(Vector3.FORWARD)) < 0.9 else Vector3.RIGHT
		var rt := nm.cross(ref).normalized()
		var bz := rt.cross(nm)
		var ps: float = par.scale.x
		n.basis = Basis(rt, nm, bz).scaled(Vector3.ONE * (s / ps))
		n.position = nm * float(RAD["planet"])
		n.set_meta("wr", 0.5)
	else:
		stage.add_child(n)
		n.scale = Vector3.ONE * s
		n.position = Vector3(float(e["x"]), float(HGT[k]) * float(RAD[k]) * s, float(e["z"]))
		n.set_meta("wr", 2.0)
	nodes[int(e["id"])] = n
	n.set_meta("k", k)
	if n.has_meta("a"):
		anims.append(n)


func animate(dt: float) -> void:
	for n in anims:
		if not is_instance_valid(n):
			continue
		var a: String = n.get_meta("a")
		var sd: float = n.get_meta("sd")
		match a:
			"spin":
				n.rotate_y(dt * float(n.get_meta("sp", 0.1)))
			"solar":
				var pv: Array = n.get_meta("pv")
				for i in pv.size():
					var p: Node3D = pv[i]
					p.rotation.y += dt * (1.2 - 0.35 * float(i))
			"pulse":
				var cor: Node3D = n.get_meta("cor")
				cor.scale = Vector3.ONE * (1.0 + 0.07 * sin(tm * 3.0 + sd * 5.0))
			"planet":
				var body: Node3D = n.get_meta("body")
				body.rotate_y(dt * 0.15)
			"bh":
				var d1: Node3D = n.get_meta("d1")
				var d2: Node3D = n.get_meta("d2")
				d1.rotate_y(dt * 0.8)
				d2.rotate_y(-dt * 1.4)
			"life":
				animate_life(n, sd)
			"fire":
				var fl: Node3D = n.get_meta("fl")
				fl.scale = Vector3(1.0 + 0.1 * sin(tm * 13.0 + sd), 1.0 + 0.25 * sin(tm * 11.0 + sd * 2.0), 1.0 + 0.1 * sin(tm * 9.0))
				var lg: OmniLight3D = n.get_meta("lg")
				lg.light_energy = 1.3 + 0.5 * sin(tm * 12.0 + sd)
			"air":
				var rings: Array = n.get_meta("rings")
				for i in rings.size():
					var rg: Node3D = rings[i]
					rg.rotate_y(dt * (1.5 + float(i) * 0.7))
			"light":
				var rays: Node3D = n.get_meta("rays")
				rays.rotate_y(dt * 0.8)
				rays.rotate_x(dt * 0.4)
			"water":
				var rp: Node3D = n.get_meta("rp")
				rp.scale = Vector3.ONE * (1.0 + 0.12 * sin(tm * 2.0 + sd * 5.0))


func animate_life(n: Node3D, sd: float) -> void:
	var k: String = n.get_meta("k")
	var r: float = RAD[k]
	var wr: float = n.get_meta("wr", 1.0)
	var m: Node3D = n.get_meta("m")
	var ang := tm * 0.5 + sd * 9.0
	match k:
		"fish":
			m.position = Vector3(cos(ang), 0.1 * sin(tm * 3.0 + sd), sin(ang)) * wr * r
			m.rotation.y = atan2(-sin(ang), cos(ang))
			m.rotation.z = sin(tm * 6.0 + sd) * 0.15
		"plant":
			m.rotation.z = sin(tm * 1.5 + sd * 8.0) * 0.08
		_:
			var ang2 := ang * 0.8
			m.position = Vector3(sin(ang), absf(sin(tm * 6.0 + sd)) * r * 0.08, cos(ang2)) * wr * r * 0.8
			m.position.y = absf(sin(tm * 6.0 + sd)) * r * 0.08
			m.rotation.y = atan2(cos(ang), -0.8 * sin(ang2))


# ============================================================
#  بناء الواجهة
# ============================================================
func full(c: Control) -> void:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func place(c: Control, al: float, at: float, ar: float, ab: float, ol := 0.0, ot := 0.0, or_ := 0.0, ob := 0.0) -> void:
	c.anchor_left = al
	c.anchor_top = at
	c.anchor_right = ar
	c.anchor_bottom = ab
	c.offset_left = ol
	c.offset_top = ot
	c.offset_right = or_
	c.offset_bottom = ob


func clear_node(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()


func on_btn(cb: Callable) -> void:
	play("click")
	cb.call()


func btn(text: String, cb: Callable, col := Color(0.2, 0.15, 0.5), fs := 36) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", fs)
	b.add_theme_stylebox_override("normal", mk_style(col))
	b.add_theme_stylebox_override("hover", mk_style(col.lightened(0.12)))
	b.add_theme_stylebox_override("pressed", mk_style(col.lightened(0.25)))
	b.custom_minimum_size = Vector2(0, 84)
	b.pressed.connect(on_btn.bind(cb))
	return b


func lbl(text: String, fs := 36, col := Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


func make_ui_root(name_id: String, mouse_ignore := true) -> Control:
	var c := Control.new()
	hud_root.add_child(c)
	full(c)
	if mouse_ignore:
		c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui[name_id] = c
	return c


func make_overlay(name_id: String, l: float, t: float, r: float, b: float) -> VBoxContainer:
	var o := make_ui_root(name_id, false)
	var dim := ColorRect.new()
	o.add_child(dim)
	full(dim)
	dim.color = Color(0, 0, 0, 0.62)
	var pc := PanelContainer.new()
	o.add_child(pc)
	place(pc, l, t, r, b)
	pc.add_theme_stylebox_override("panel", mk_style(Color(0.06, 0.05, 0.2, 0.99), 28, Color(0.6, 0.5, 1, 0.5)))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	pc.add_child(vb)
	return vb


func mk_bar(col: Color, h: float) -> ProgressBar:
	var b := ProgressBar.new()
	b.show_percentage = false
	b.custom_minimum_size = Vector2(0, h)
	b.add_theme_stylebox_override("fill", mk_style(col, 10, Color(0, 0, 0, 0)))
	b.add_theme_stylebox_override("background", mk_style(Color(0, 0, 0, 0.6), 10, Color(1, 1, 1, 0.3)))
	return b


func build_ui() -> void:
	# ----- القائمة -----
	var m := make_ui_root("menu")
	var t1 := lbl("إله الخلق", 150, Color(1, 0.92, 0.65))
	m.add_child(t1)
	place(t1, 0, 0.12, 1, 0.12)
	var t2 := lbl("OmniForge 3D", 54, Color(0.7, 0.85, 1.0))
	m.add_child(t2)
	place(t2, 0, 0.12, 1, 0.12, 0, 190, 0, 190)
	var t3 := lbl("كن الإله المطلق · اخلق الأكوان · اهزم الآلهة", 36, Color(0.85, 0.85, 1.0))
	m.add_child(t3)
	place(t3, 0, 0.12, 1, 0.12, 0, 280, 0, 280)
	var mv := VBoxContainer.new()
	m.add_child(mv)
	place(mv, 0.1, 0.7, 0.9, 0.7)
	mv.add_theme_constant_override("separation", 26)
	var b1 := btn("متابعة الخلق", continue_game, Color(0.3, 0.2, 0.75), 52)
	b1.custom_minimum_size = Vector2(0, 130)
	mv.add_child(b1)
	var b2 := btn("عالم جديد", new_game, Color(0.15, 0.12, 0.4), 44)
	b2.custom_minimum_size = Vector2(0, 110)
	mv.add_child(b2)

	# ----- العالم -----
	var w := make_ui_root("world")
	var top := PanelContainer.new()
	w.add_child(top)
	place(top, 0, 0, 1, 0, 0, 0, 0, 150)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	top.add_child(hb)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(info)
	lbl_power = lbl("", 32)
	info.add_child(lbl_power)
	xp_bar = mk_bar(Color(0.5, 0.85, 1.0), 22)
	info.add_child(xp_bar)
	hb.add_child(btn("حرب العوالم", open_gods, Color(0.7, 0.15, 0.2), 30))
	hb.add_child(btn("المهارات", open_skills, Color(0.25, 0.2, 0.7), 30))

	bot_panel = PanelContainer.new()
	w.add_child(bot_panel)
	place(bot_panel, 0, 1, 1, 1, 0, -440, 0, 0)
	var bv := VBoxContainer.new()
	bv.add_theme_constant_override("separation", 8)
	bot_panel.add_child(bv)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	bv.add_child(tabs)
	for i in CATS.size():
		var tb := btn(CATS[i]["n"], select_cat.bind(i), Color(0.2, 0.15, 0.5), 26)
		tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tb.custom_minimum_size = Vector2(0, 76)
		tabs.add_child(tb)
		tab_btns.append(tb)
	var tdefs := [["تحريك", "move", Color(0.1, 0.4, 0.45)], ["إزالة", "erase", Color(0.5, 0.15, 0.2)], ["إزاحة", "pan", Color(0.3, 0.3, 0.12)]]
	for d in tdefs:
		var tb2 := btn(d[0], select_tool.bind(d[1]), d[2], 26)
		tb2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tb2.custom_minimum_size = Vector2(0, 76)
		tabs.add_child(tb2)
		tab_btns.append(tb2)

	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 200)
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	bv.add_child(sc)
	pal_box = HBoxContainer.new()
	pal_box.add_theme_constant_override("separation", 10)
	sc.add_child(pal_box)

	var hr := HBoxContainer.new()
	hr.add_theme_constant_override("separation", 10)
	bv.add_child(hr)
	var sm := btn("−", change_size.bind(-0.25), Color(0.2, 0.15, 0.5), 36)
	sm.custom_minimum_size = Vector2(110, 70)
	hr.add_child(sm)
	lbl_hint = lbl("", 26, Color(0.8, 0.85, 1))
	lbl_hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lbl_hint.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hr.add_child(lbl_hint)
	var sp := btn("+", change_size.bind(0.25), Color(0.2, 0.15, 0.5), 36)
	sp.custom_minimum_size = Vector2(110, 70)
	hr.add_child(sp)

	var zi := btn("+", zoom_by.bind(0.8), Color(0.1, 0.1, 0.35), 44)
	w.add_child(zi)
	place(zi, 1, 0, 1, 0, -120, 170, -20, 270)
	var zo := btn("−", zoom_by.bind(1.25), Color(0.1, 0.1, 0.35), 44)
	w.add_child(zo)
	place(zo, 1, 0, 1, 0, -120, 285, -20, 385)

	# ----- زيارة عالم إله -----
	var vs := make_ui_root("visit")
	var vpn := PanelContainer.new()
	vs.add_child(vpn)
	place(vpn, 0, 1, 1, 1, 0, -270, 0, 0)
	var vv := VBoxContainer.new()
	vv.add_theme_constant_override("separation", 12)
	vpn.add_child(vv)
	visit_lbl = lbl("", 40, Color(1, 0.9, 0.6))
	vv.add_child(visit_lbl)
	var vh := HBoxContainer.new()
	vh.add_theme_constant_override("separation", 14)
	vv.add_child(vh)
	var vb1 := btn("أعلن الحرب", visit_war, Color(0.7, 0.15, 0.2), 36)
	vb1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vh.add_child(vb1)
	var vb2 := btn("العودة لعالمي", enter_world, Color(0.25, 0.2, 0.7), 36)
	vb2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vh.add_child(vb2)

	# ----- الحرب -----
	var wr := make_ui_root("war")
	war_lbl = lbl("", 38, Color(1, 0.9, 0.7))
	wr.add_child(war_lbl)
	place(war_lbl, 0, 0, 1, 0, 0, 40, 0, 140)
	var wb := HBoxContainer.new()
	wb.add_theme_constant_override("separation", 20)
	wr.add_child(wb)
	place(wb, 0.06, 1, 0.94, 1, 0, -170, 0, -50)
	var spd := btn("تسريع", toggle_speed, Color(0.25, 0.2, 0.7), 36)
	spd.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wb.add_child(spd)
	var ret := btn("انسحاب", retreat, Color(0.5, 0.15, 0.2), 36)
	ret.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wb.add_child(ret)

	# ----- المبارزة -----
	var du := make_ui_root("duel")
	lbl_god = lbl("", 44, Color.WHITE)
	du.add_child(lbl_god)
	place(lbl_god, 0, 0, 1, 0, 0, 30, 0, 100)
	bar_god = mk_bar(Color(1, 0.5, 0.3), 32)
	du.add_child(bar_god)
	place(bar_god, 0.08, 0, 0.92, 0, 0, 105, 0, 137)
	var mebox := VBoxContainer.new()
	mebox.add_theme_constant_override("separation", 6)
	du.add_child(mebox)
	place(mebox, 0.08, 1, 0.92, 1, 0, -690, 0, -540)
	mebox.add_child(lbl("الخالق المطلق", 34, Color(0.8, 0.95, 1)))
	bar_me = mk_bar(Color(0.4, 0.85, 1.0), 30)
	mebox.add_child(bar_me)
	bar_en = mk_bar(Color(1, 0.85, 0.3), 18)
	mebox.add_child(bar_en)
	duel_log = lbl("", 32, Color(1, 0.95, 0.8))
	duel_log.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	du.add_child(duel_log)
	place(duel_log, 0.04, 1, 0.96, 1, 0, -520, 0, -380)
	var dg_grid := GridContainer.new()
	dg_grid.columns = 2
	dg_grid.add_theme_constant_override("h_separation", 16)
	dg_grid.add_theme_constant_override("v_separation", 16)
	du.add_child(dg_grid)
	place(dg_grid, 0.04, 1, 0.96, 1, 0, -360, 0, -40)
	var defs := [
		["ضربة كونية", "atk", Color(0.7, 0.2, 0.25)],
		["انفجار نجمي (40)", "big", Color(0.8, 0.4, 0.1)],
		["درع إلهي", "shield", Color(0.15, 0.4, 0.75)],
		["شفاء (30)", "heal", Color(0.15, 0.55, 0.35)],
	]
	for d in defs:
		var db := btn(d[0], p_act.bind(d[1]), d[2], 34)
		db.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		db.custom_minimum_size = Vector2(0, 150)
		dg_grid.add_child(db)
		duel_btns.append(db)

	skills_vb = make_overlay("skills", 0.04, 0.14, 0.96, 0.86)
	gods_vb = make_overlay("gods", 0.03, 0.08, 0.97, 0.92)
	var rv := make_overlay("result", 0.08, 0.28, 0.92, 0.72)
	res_lbl = lbl("", 40)
	res_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	res_lbl.custom_minimum_size = Vector2(700, 300)
	res_lbl.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rv.add_child(res_lbl)
	rv.add_child(btn("متابعة", close_result, Color(0.3, 0.2, 0.75), 44))

	toast_lbl = lbl("", 34, Color(1, 0.95, 0.7))
	toast_lbl.add_theme_stylebox_override("normal", mk_style(Color(0.05, 0.03, 0.2, 0.92), 20, Color(1, 0.9, 0.5, 0.5)))
	hud_root.add_child(toast_lbl)
	place(toast_lbl, 0.1, 0, 0.9, 0, 0, 165, 0, 165)
	toast_lbl.modulate.a = 0.0

	rebuild_palette()


func toast(msg: String) -> void:
	toast_lbl.text = msg
	toast_lbl.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(1.6)
	tw.tween_property(toast_lbl, "modulate:a", 0.0, 0.6)


func pop_text(t: String, wp: Vector3, col: Color) -> void:
	var l := lbl(t, 60, col)
	hud_root.add_child(l)
	var sp := cam.unproject_position(wp)
	l.position = sp - Vector2(100, 40)
	l.custom_minimum_size = Vector2(200, 0)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 120.0, 1.1)
	tw.tween_property(l, "modulate:a", 0.0, 1.1)
	tw.chain().tween_callback(l.queue_free)


func go(s: String) -> void:
	screen = s
	for k in ["menu", "world", "war", "duel"]:
		ui[k].visible = (k == s)
	for k in ["skills", "gods", "result"]:
		ui[k].visible = false
	ui["visit"].visible = (s == "world" and view >= 0)
	bot_panel.visible = (view < 0)
	stage.visible = (s == "menu" or s == "world")
	arena.visible = (s == "war")
	duel_root.visible = (s == "duel")
	if s == "world":
		refresh()


func refresh() -> void:
	var pw := player_power()
	lbl_power.text = "المستوى %d   |   القوة %d" % [int(data["level"]), int(pw)]
	xp_bar.max_value = float(xp_need())
	xp_bar.value = float(int(data["xp"]))
	match tool:
		"move":
			lbl_hint.text = "اسحب لتدوير الكاميرا أو حرّك الأجرام"
		"erase":
			lbl_hint.text = "المس أي شيء لإزالته"
		"pan":
			lbl_hint.text = "اسحب لإزاحة الكاميرا"
		_:
			var nm: String = ITEMS[tool]["n"]
			if ON_PLANET.has(tool):
				lbl_hint.text = "المس كوكباً أو الفضاء لخلق: %s (الحجم %.2f)" % [nm, place_scale]
			else:
				lbl_hint.text = "المس الفضاء لخلق: %s (الحجم %.2f)" % [nm, place_scale]
	for i in tab_btns.size():
		var active := false
		if i < CATS.size():
			active = (i == cat_idx)
		elif i == CATS.size():
			active = (tool == "move")
		elif i == CATS.size() + 1:
			active = (tool == "erase")
		else:
			active = (tool == "pan")
		tab_btns[i].modulate = Color(1, 1, 1) if active else Color(0.65, 0.65, 0.8)


func select_cat(i: int) -> void:
	cat_idx = i
	rebuild_palette()
	refresh()


func select_tool(k: String) -> void:
	tool = k
	refresh()


func change_size(d: float) -> void:
	place_scale = clampf(place_scale + d, 0.25, 4.0)
	refresh()


func zoom_by(f: float) -> void:
	dist = clampf(dist * f, 4.0, 140.0)


func rebuild_palette() -> void:
	clear_node(pal_box)
	var keys: Array = CATS[cat_idx]["k"]
	for k in keys:
		var key: String = k
		var px := Proxy.new()
		px.custom_minimum_size = Vector2(150, 190)
		px.mouse_filter = Control.MOUSE_FILTER_PASS
		px.cb = draw_icon.bind(key)
		px.tapped.connect(pick_item.bind(key))
		pal_box.add_child(px)


func pick_item(k: String) -> void:
	tool = k
	play("click")
	refresh()


func ellipse_pts(c: Vector2, rx: float, ry: float, n := 22) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n:
		var a := float(i) / float(n) * TAU
		pts.append(c + Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func draw_icon(ci: Control, k: String) -> void:
	var sel := (tool == k)
	var bg: Color = Color(0.25, 0.2, 0.6, 0.95) if sel else Color(0.1, 0.08, 0.28, 0.95)
	ci.draw_rect(Rect2(Vector2.ZERO, ci.size), bg)
	ci.draw_rect(Rect2(Vector2.ZERO, ci.size), Color(1, 0.9, 0.5, 0.9) if sel else Color(1, 1, 1, 0.12), false, 3.0)
	var c := Vector2(ci.size.x * 0.5, 78.0)
	match k:
		"universe":
			ci.draw_circle(c, 40.0, Color(0.5, 0.35, 1.0, 0.35))
			ci.draw_arc(c, 40.0, 0.0, TAU, 40, Color(0.8, 0.6, 1.0), 3.0, true)
			for i in 7:
				ci.draw_circle(c + Vector2.from_angle(float(i) * 1.1) * (8.0 + float(i) * 4.0), 2.5, Color.WHITE)
		"galaxy":
			for arm in 2:
				var pts := PackedVector2Array()
				for i in 30:
					var f := float(i) / 29.0
					var a := f * 5.0 + float(arm) * PI + tm * 0.5
					pts.append(c + Vector2(cos(a), sin(a)) * 42.0 * f)
				ci.draw_polyline(pts, Color(0.6, 0.75, 1.0), 4.0, true)
			ci.draw_circle(c, 8.0, Color(1, 0.9, 0.6))
		"solar":
			ci.draw_circle(c, 11.0, Color(1, 0.85, 0.3))
			ci.draw_arc(c, 30.0, 0.0, TAU, 30, Color(1, 1, 1, 0.3), 2.0)
			var a2 := tm * 1.5
			ci.draw_circle(c + Vector2(cos(a2), sin(a2)) * 30.0, 6.0, Color(0.4, 0.7, 1))
		"star":
			ci.draw_circle(c, 30.0, Color(1, 0.9, 0.5, 0.2))
			ci.draw_circle(c, 15.0, Color(1, 0.97, 0.8))
			ci.draw_line(c - Vector2(36, 0), c + Vector2(36, 0), Color(1, 1, 0.8, 0.7), 2.0)
			ci.draw_line(c - Vector2(0, 36), c + Vector2(0, 36), Color(1, 1, 0.8, 0.7), 2.0)
		"planet":
			ci.draw_arc(c, 40.0, 0.0, TAU, 30, Color(0.9, 0.85, 0.7, 0.6), 3.0)
			ci.draw_circle(c, 28.0, Color(0.3, 0.55, 0.85))
			ci.draw_circle(c + Vector2(-8, -8), 10.0, Color(0.4, 0.8, 0.45, 0.8))
		"blackhole":
			ci.draw_colored_polygon(ellipse_pts(c, 44.0, 14.0, 30), Color(1, 0.55, 0.15))
			ci.draw_circle(c, 20.0, Color.BLACK)
		"human":
			ci.draw_circle(c + Vector2(0, -26), 10.0, Color(1, 0.85, 0.7))
			ci.draw_line(c + Vector2(0, -16), c + Vector2(0, 10), Color(0.4, 0.6, 1), 14.0)
			ci.draw_line(c + Vector2(-6, 10), c + Vector2(-8, 34), Color(0.3, 0.3, 0.6), 6.0)
			ci.draw_line(c + Vector2(6, 10), c + Vector2(8, 34), Color(0.3, 0.3, 0.6), 6.0)
		"animal":
			var col := Color(0.7, 0.45, 0.25)
			ci.draw_colored_polygon(ellipse_pts(c + Vector2(0, 4), 30.0, 16.0, 20), col)
			ci.draw_circle(c + Vector2(30, -8), 10.0, col.lightened(0.1))
			for i in 4:
				ci.draw_line(c + Vector2(-18.0 + 12.0 * float(i), 14), c + Vector2(-18.0 + 12.0 * float(i), 32), col.darkened(0.3), 5.0)
		"plant":
			ci.draw_line(c + Vector2(0, 34), c + Vector2(0, -6), Color(0.2, 0.7, 0.3), 6.0)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -40), c + Vector2(-24, 0), c + Vector2(24, 0)]), Color(0.25, 0.75, 0.35))
		"fish":
			var fc := Color(1, 0.6, 0.2)
			ci.draw_colored_polygon(ellipse_pts(c, 28.0, 16.0, 20), fc)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-22, 0), c + Vector2(-42, -14), c + Vector2(-42, 14)]), fc.darkened(0.15))
			ci.draw_circle(c + Vector2(14, -4), 4.0, Color.WHITE)
		"water":
			ci.draw_circle(c + Vector2(0, 8), 22.0, Color(0.25, 0.6, 1.0))
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -34), c + Vector2(-21, 4), c + Vector2(21, 4)]), Color(0.25, 0.6, 1.0))
		"earth":
			ci.draw_colored_polygon(ellipse_pts(c, 34.0, 22.0, 9), Color(0.5, 0.34, 0.2))
			ci.draw_arc(c, 26.0, PI * 1.1, PI * 1.9, 12, Color(0.3, 0.75, 0.3), 8.0)
		"fire":
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -38), c + Vector2(-24, 6), c + Vector2(0, 30), c + Vector2(24, 6)]), Color(1, 0.4, 0.1))
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -16), c + Vector2(-12, 8), c + Vector2(0, 22), c + Vector2(12, 8)]), Color(1, 0.9, 0.3))
		"air":
			for i in 3:
				ci.draw_arc(c + Vector2(0, -20.0 + 20.0 * float(i)), 22.0, PI * 0.1, PI * 1.1, 14, Color(0.85, 0.95, 1.0), 4.0, true)
		"light":
			ci.draw_circle(c, 14.0, Color(1, 1, 0.85))
			for i in 8:
				var a := float(i) * TAU / 8.0 + tm
				ci.draw_line(c + Vector2.from_angle(a) * 20.0, c + Vector2.from_angle(a) * 38.0, Color(1, 0.95, 0.6), 3.0)
	var nm: String = ITEMS[k]["n"]
	ci.draw_string(fnt, Vector2(0, 168), nm, HORIZONTAL_ALIGNMENT_CENTER, ci.size.x, 30, Color.WHITE)


# ============================================================
#  القوائم: المهارات والآلهة والنتيجة
# ============================================================
func open_skills() -> void:
	ui["skills"].visible = true
	rebuild_skills()


func rebuild_skills() -> void:
	clear_node(skills_vb)
	skills_vb.add_child(lbl("شجرة المهارات", 48, Color(1, 0.9, 0.6)))
	skills_vb.add_child(lbl("نقاط المهارة: %d" % int(data["points"]), 38, Color(0.7, 0.9, 1)))
	for s in SKILLS:
		var id: String = s["id"]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		skills_vb.add_child(row)
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(col)
		col.add_child(lbl("%s  (%d/5)" % [String(s["n"]), skill(id)], 38, Color(1, 0.9, 0.6)))
		var d := lbl(String(s["d"]), 28, Color(0.8, 0.85, 1))
		d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		d.custom_minimum_size = Vector2(200, 0)
		col.add_child(d)
		var ub := btn("ترقية", upgrade.bind(id), Color(0.2, 0.5, 0.3), 32)
		ub.custom_minimum_size = Vector2(190, 90)
		ub.disabled = (skill(id) >= 5 or int(data["points"]) < 1)
		row.add_child(ub)
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	skills_vb.add_child(sp)
	skills_vb.add_child(btn("العودة للقائمة الرئيسية", to_menu, Color(0.3, 0.15, 0.25), 32))
	skills_vb.add_child(btn("إغلاق", close_overlays, Color(0.3, 0.2, 0.75), 38))


func upgrade(id: String) -> void:
	if skill(id) >= 5 or int(data["points"]) < 1:
		return
	data["skills"][id] = skill(id) + 1
	data["points"] = int(data["points"]) - 1
	play("win")
	save_game()
	refresh()
	rebuild_skills.call_deferred()


func close_overlays() -> void:
	ui["skills"].visible = false
	ui["gods"].visible = false
	refresh()


func to_menu() -> void:
	save_game()
	view = -1
	rebuild_world()
	target = Vector3.ZERO
	dist = 16.0
	go("menu")


func open_gods() -> void:
	ui["gods"].visible = true
	rebuild_gods()


func rebuild_gods() -> void:
	clear_node(gods_vb)
	gods_vb.add_child(lbl("آلهة العوالم", 48, Color(1, 0.6, 0.5)))
	var pw := player_power()
	gods_vb.add_child(lbl("قوتك الإلهية: %d" % int(pw), 36, Color(0.7, 0.9, 1)))
	for i in gods.size():
		var g: Dictionary = gods[i]
		var gcol := Color.html(str(g["col"]))
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel", mk_style(Color(0.1, 0.08, 0.3, 0.98), 22, gcol))
		gods_vb.add_child(card)
		var vb := VBoxContainer.new()
		vb.add_theme_constant_override("separation", 8)
		card.add_child(vb)
		vb.add_child(lbl(String(g["n"]), 40, gcol))
		var ds := lbl(String(g["desc"]), 26, Color(0.8, 0.85, 1))
		ds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ds.custom_minimum_size = Vector2(300, 0)
		vb.add_child(ds)
		var gp: float = g["power"]
		var chance := int(100.0 * pw / (pw + gp))
		vb.add_child(lbl("قوته: %d   |   فرصتك: %d%%" % [int(gp), chance], 28, Color(1, 0.9, 0.6)))
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 12)
		vb.add_child(hb)
		var b1 := btn("زيارة عالمه", visit.bind(i), Color(0.2, 0.3, 0.6), 30)
		b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(b1)
		var b2 := btn("أعلن الحرب", start_war.bind(i), Color(0.7, 0.15, 0.2), 30)
		b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(b2)
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	gods_vb.add_child(sp)
	gods_vb.add_child(btn("إغلاق", close_overlays, Color(0.3, 0.2, 0.75), 38))


func visit(i: int) -> void:
	view = i
	rebuild_world()
	var g: Dictionary = gods[i]
	visit_lbl.text = "عالم %s" % String(g["n"])
	target = world_center(g["ents"])
	dist = 34.0
	go("world")


func visit_war() -> void:
	start_war(view)


func enter_world() -> void:
	view = -1
	rebuild_world()
	target = world_center(ents)
	dist = 16.0
	go("world")


func show_result(text: String) -> void:
	res_lbl.text = text
	ui["result"].visible = true


func close_result() -> void:
	ui["result"].visible = false
	enter_world()


# ============================================================
#  القائمة الرئيسية
# ============================================================
func continue_game() -> void:
	if not load_game():
		data = default_data()
		ents = data["ents"]
		gods = data["gods"]
	enter_world()


func new_game() -> void:
	data = default_data()
	ents = data["ents"]
	gods = data["gods"]
	save_game()
	enter_world()


# ============================================================
#  الكاميرا والإدخال
# ============================================================
func apply_orbit() -> void:
	var off := Vector3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch)) * dist
	cam.position = target + off
	cam.look_at(target, Vector3.UP)


func update_camera(dt: float) -> void:
	match screen:
		"menu":
			yaw += dt * 0.1
			apply_orbit()
		"world":
			apply_orbit()
		"war":
			var a := sin(tm * 0.15) * 0.35
			cam.position = Vector3(sin(a) * 26.0, 15.0, cos(a) * 26.0)
			cam.look_at(Vector3(0, 0, 0), Vector3.UP)
		"duel":
			var sh := maxf(shake_p, shake_g) * 0.25
			cam.position = Vector3(randf_range(-sh, sh), 3.6 + randf_range(-sh, sh), 12.5)
			cam.look_at(Vector3(0, 1.7, 0), Vector3.UP)


func ray_plane(sp: Vector2, y := 0.0) -> Variant:
	var o := cam.project_ray_origin(sp)
	var d := cam.project_ray_normal(sp)
	if absf(d.y) < 0.0001:
		return null
	var t := (y - o.y) / d.y
	if t < 0.0:
		return null
	return o + d * t


func pick_ent(sp: Vector2, free_only: bool) -> int:
	var o := cam.project_ray_origin(sp)
	var d := cam.project_ray_normal(sp)
	var best := -1
	var bs := 1e12
	for e in cur_ents():
		if free_only and e.has("on"):
			continue
		var id := int(e["id"])
		var nd: Node3D = nodes.get(id)
		if nd == null:
			continue
		var k: String = e["k"]
		var rad: float = maxf(float(RAD[k]) * float(e["s"]) * 1.15, 0.7)
		var oc := nd.global_position - o
		var t := oc.dot(d)
		if t < 0.0:
			continue
		var dd := (oc - d * t).length()
		if dd <= rad:
			var score := rad * 1000.0 + t
			if score < bs:
				bs = score
				best = id
	return best


func _unhandled_input(ev: InputEvent) -> void:
	if screen != "world":
		return
	if ev is InputEventMouseButton:
		if ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed:
				dragging = true
				moved = false
				press_pos = ev.position
				drag_id = -1
				if view < 0 and tool == "move":
					var hit := pick_ent(ev.position, true)
					if hit >= 0:
						var h = ray_plane(ev.position, 0.0)
						var e := find_ent(hit)
						if h is Vector3 and not e.is_empty():
							drag_id = hit
							drag_off = Vector3(float(e["x"]), 0, float(e["z"])) - Vector3(h.x, 0, h.z)
			else:
				if dragging and not moved:
					tap(ev.position)
				if dragging and moved and drag_id >= 0:
					save_game()
				dragging = false
				drag_id = -1
		elif ev.button_index == MOUSE_BUTTON_WHEEL_UP and ev.pressed:
			zoom_by(0.9)
		elif ev.button_index == MOUSE_BUTTON_WHEEL_DOWN and ev.pressed:
			zoom_by(1.1)
	elif ev is InputEventMouseMotion and dragging:
		if ev.position.distance_to(press_pos) > 14.0:
			moved = true
		if moved:
			if drag_id >= 0:
				var h2 = ray_plane(ev.position, 0.0)
				var e2 := find_ent(drag_id)
				if h2 is Vector3 and not e2.is_empty():
					e2["x"] = h2.x + drag_off.x
					e2["z"] = h2.z + drag_off.z
					var nd: Node3D = nodes.get(drag_id)
					if nd != null:
						nd.position = Vector3(float(e2["x"]), nd.position.y, float(e2["z"]))
			elif tool == "pan":
				var right := cam.global_transform.basis.x
				var fwd := -cam.global_transform.basis.z
				right.y = 0.0
				fwd.y = 0.0
				target += (-right.normalized() * ev.relative.x + fwd.normalized() * ev.relative.y) * dist * 0.0018
			else:
				yaw -= ev.relative.x * 0.006
				pitch = clampf(pitch + ev.relative.y * 0.006, 0.12, 1.5)


func tap(sp: Vector2) -> void:
	if view >= 0:
		return
	if tool == "erase":
		var id := pick_ent(sp, false)
		if id >= 0:
			remove_ent(id)
	elif tool != "move" and tool != "pan":
		place_item(sp)


func remove_ent(id: int) -> void:
	var kill: Array = [id]
	for e in ents:
		if e.has("on") and int(e["on"]) == id:
			kill.append(int(e["id"]))
	var nd: Node3D = nodes.get(id)
	if nd != null:
		burst3(nd.global_position, Color(1, 0.5, 0.4), 14)
	ents = ents.filter(func(e): return not kill.has(int(e["id"])))
	data["ents"] = ents
	for kid in kill:
		var n: Node3D = nodes.get(kid)
		if n != null and is_instance_valid(n):
			anims.erase(n)
		nodes.erase(kid)
	if nd != null:
		nd.queue_free()
	play("erase")
	refresh()
	save_game()


func place_item(sp: Vector2) -> void:
	var o := cam.project_ray_origin(sp)
	var d := cam.project_ray_normal(sp)
	var e: Dictionary = {}
	if ON_PLANET.has(tool):
		var best_t := 1e9
		var best_id := -1
		var best_pt := Vector3.ZERO
		for pe in ents:
			if String(pe["k"]) != "planet":
				continue
			var pn: Node3D = nodes.get(int(pe["id"]))
			if pn == null:
				continue
			var R := float(RAD["planet"]) * float(pe["s"])
			var oc := o - pn.global_position
			var b := oc.dot(d)
			var cc := oc.dot(oc) - R * R
			var disc := b * b - cc
			if disc >= 0.0:
				var t := -b - sqrt(disc)
				if t > 0.0 and t < best_t:
					best_t = t
					best_id = int(pe["id"])
					best_pt = o + d * t
		if best_id >= 0:
			var par: Node3D = nodes.get(best_id)
			var body: Node3D = par.get_meta("body")
			var nm := body.to_local(best_pt).normalized()
			e = {"id": new_id(), "k": tool, "on": best_id, "nx": nm.x, "ny": nm.y, "nz": nm.z, "s": place_scale, "seed": randf()}
	if e.is_empty():
		var h = ray_plane(sp, 0.0)
		if not (h is Vector3):
			return
		var hp: Vector3 = h
		hp.x = clampf(hp.x, -200.0, 200.0)
		hp.z = clampf(hp.z, -200.0, 200.0)
		e = {"id": new_id(), "k": tool, "x": hp.x, "z": hp.z, "s": place_scale, "seed": randf()}
	ents.append(e)
	add_ent_node(e)
	var nn: Node3D = nodes.get(int(e["id"]))
	if nn != null:
		burst3(nn.global_position, Color(0.8, 0.9, 1.0), 16)
	play("place")
	var p: float = ITEMS[tool]["p"]
	add_xp(3 + int(p / 10.0))
	refresh()
	save_game()


# ============================================================
#  جسيمات ومقذوفات
# ============================================================
func burst3(wp: Vector3, col: Color, n: int) -> void:
	if fxs.size() > 160:
		return
	var m := mat(col, 3.0)
	var sm := SphereMesh.new()
	sm.radius = 0.08
	sm.height = 0.16
	sm.radial_segments = 6
	sm.rings = 3
	for i in n:
		var node := MeshInstance3D.new()
		node.mesh = sm
		node.material_override = m
		node.position = wp
		fx.add_child(node)
		var v := Vector3(randf_range(-1, 1), randf_range(-0.2, 1.2), randf_range(-1, 1)).normalized() * randf_range(1.0, 4.5)
		fxs.append({"n": node, "v": v, "l": 1.0})


func update_fx(dt: float) -> void:
	for f in fxs:
		var n: Node3D = f["n"]
		f["l"] = float(f["l"]) - dt * 1.4
		if float(f["l"]) <= 0.0:
			n.queue_free()
		else:
			n.position += Vector3(f["v"]) * dt
			n.scale = Vector3.ONE * clampf(float(f["l"]), 0.05, 1.0)
	fxs = fxs.filter(func(f): return float(f["l"]) > 0.0)


func fire_projectile(from: Vector3, to: Vector3, col: Color, big: bool) -> void:
	var p := Node3D.new()
	fx.add_child(p)
	p.position = from
	var rr: float = 0.3
	if big:
		rr = 0.6
	sph(p, rr, mat(col, 4.0), Vector3.ZERO, 14)
	omni(p, col, 2.0, 8.0)
	play("shoot")
	var tw := create_tween()
	tw.tween_property(p, "position", to, 0.5)
	await tw.finished
	p.queue_free()


# ============================================================
#  حرب العوالم (معركة ثلاثية الأبعاد)
# ============================================================
func build_arena(gcol: Color) -> void:
	for c in arena.get_children():
		arena.remove_child(c)
		c.queue_free()
	cyl(arena, 18.0, 18.0, 0.5, mat(Color(0.08, 0.07, 0.18), 0.0, 1.0, 0.9), Vector3(0, -0.25, 0))
	tor(arena, 17.6, 18.0, mat(Color(0.6, 0.5, 1.0), 2.0), Vector3(0, 0.02, 0), 48)
	cyl(arena, 8.0, 8.0, 0.03, mat(Color(0.3, 0.6, 1.0), 1.5, 0.35), Vector3(0, 0.02, 9.0))
	cyl(arena, 8.0, 8.0, 0.03, mat(gcol, 1.5, 0.35), Vector3(0, 0.02, -9.0))
	box(arena, Vector3(36, 0.03, 0.2), mat(Color(1, 1, 1), 1.5, 0.5), Vector3(0, 0.03, 0))
	omni(arena, Color(1, 0.95, 0.9), 1.6, 40.0, Vector3(0, 14, 0))
	omni(arena, Color(0.4, 0.6, 1.0), 1.0, 25.0, Vector3(0, 6, 12))
	omni(arena, gcol, 1.0, 25.0, Vector3(0, 6, -12))


func start_war(gi: int) -> void:
	war_god = gi
	var g: Dictionary = gods[gi]
	var gcol := Color.html(str(g["col"]))
	var pw := player_power()
	var gp: float = g["power"]
	var np := clampi(count_life(ents) + 6, 6, 28)
	var ng := clampi(count_life(g["ents"]) + 6, 6, 28)
	var kinds: Array = []
	for e in ents:
		if String(e["k"]) == "human" or String(e["k"]) == "animal":
			kinds.append(e["k"])
	if kinds.is_empty():
		kinds.append("human")
	build_arena(gcol)
	units.clear()
	for i in np:
		var n := build_ent(String(kinds[i % kinds.size()]), randf())
		arena.add_child(n)
		var p := Vector3(randf_range(-11.0, 11.0), 0, randf_range(5.0, 12.0))
		n.position = p
		n.scale = Vector3.ONE * 2.2
		units.append({"side": 0, "n": n, "p": p, "hp": 3.0, "cd": randf(), "flash": 0.0, "bs": 2.2, "dead": false})
	for i in ng:
		var n := build_minion(gcol)
		arena.add_child(n)
		var p := Vector3(randf_range(-11.0, 11.0), 0, randf_range(-12.0, -5.0))
		n.position = p
		n.scale = Vector3.ONE * 1.4
		units.append({"side": 1, "n": n, "p": p, "hp": 3.0, "cd": randf(), "flash": 0.0, "bs": 1.4, "dead": false})
	fp = clampf(2.0 * pw / (pw + gp), 0.5, 1.6)
	fg = clampf(2.0 * gp / (pw + gp), 0.5, 1.6)
	war_over = false
	war_won = false
	war_t = 0.0
	war_end_t = 0.0
	war_speed = 1.0
	war_lbl.text = ""
	go("war")


func toggle_speed() -> void:
	war_speed = 2.5 if war_speed < 2.0 else 1.0


func retreat() -> void:
	enter_world()


func alive_count(side: int) -> int:
	var c := 0
	for u in units:
		if int(u["side"]) == side and float(u["hp"]) > 0.0:
			c += 1
	return c


func upd_war(dt: float) -> void:
	if war_over:
		war_end_t -= dt
		if war_end_t <= 0.0:
			start_duel(war_won)
		return
	var d := dt * war_speed
	war_t += d
	for u in units:
		if bool(u["dead"]):
			continue
		var n: Node3D = u["n"]
		u["flash"] = maxf(0.0, float(u["flash"]) - dt)
		var bs: float = u["bs"]
		if float(u["hp"]) <= 0.0:
			u["dead"] = true
			burst3(n.position + Vector3(0, 1, 0), Color(1, 0.8, 0.4), 8)
			var tw := create_tween()
			tw.tween_property(n, "scale", Vector3.ZERO, 0.3)
			tw.tween_callback(n.queue_free)
			continue
		var side: int = u["side"]
		var up: Vector3 = u["p"]
		var best: Dictionary = {}
		var bd := 1e9
		for v in units:
			if int(v["side"]) != side and float(v["hp"]) > 0.0:
				var dd := up.distance_to(Vector3(v["p"]))
				if dd < bd:
					bd = dd
					best = v
		if not best.is_empty():
			var dir := Vector3(best["p"]) - up
			dir.y = 0.0
			if bd > 1.8:
				up += dir.normalized() * 4.5 * d
				up.x = clampf(up.x, -15.0, 15.0)
				up.z = clampf(up.z, -15.0, 15.0)
				u["p"] = up
				n.position = Vector3(up.x, absf(sin(tm * 10.0 + up.x)) * 0.18, up.z)
			else:
				u["cd"] = float(u["cd"]) - d
				if float(u["cd"]) <= 0.0:
					u["cd"] = 0.7
					var mult: float = fp if side == 0 else fg
					best["hp"] = float(best["hp"]) - mult * randf_range(0.7, 1.3)
					best["flash"] = 0.25
					burst3(Vector3(best["p"]) + Vector3(0, 1, 0), Color(1, 0.8, 0.4), 4)
					if randf() < 0.25:
						play("hit")
			if dir.length() > 0.01:
				n.rotation.y = atan2(dir.x, dir.z)
		var fl: float = u["flash"]
		var hs: float = 0.7 + 0.1 * float(u["hp"])
		n.scale = Vector3.ONE * bs * hs * (1.0 + fl * 1.2)
	var a := alive_count(0)
	var b := alive_count(1)
	war_lbl.text = "جيشك: %d      |      %s: %d" % [a, String(gods[war_god]["n"]), b]
	if a == 0 or b == 0 or war_t > 45.0:
		war_over = true
		war_won = a >= b
		war_end_t = 2.6
		war_lbl.text = "انتصر جيشك! تبدأ مبارزة الآلهة بميزة لك" if war_won else "هُزم جيشك... تبدأ مبارزة الآلهة وأنت متأخر"
		play("big")


# ============================================================
#  مبارزة الآلهة (ثلاثية الأبعاد)
# ============================================================
func build_duel_scene(gcol: Color, kind: String) -> void:
	for c in duel_root.get_children():
		duel_root.remove_child(c)
		c.queue_free()
	cyl(duel_root, 9.0, 9.0, 0.4, mat(Color(0.07, 0.06, 0.18), 0.0, 1.0, 0.9), Vector3(0, -0.2, 0))
	tor(duel_root, 8.6, 9.0, mat(Color(0.6, 0.5, 1.0), 2.0), Vector3(0, 0.02, 0), 48)
	cyl(duel_root, 2.0, 2.0, 0.04, mat(Color(0.4, 0.8, 1.0), 2.0, 0.5), Vector3(P_ME.x, 0.02, 0))
	cyl(duel_root, 2.0, 2.0, 0.04, mat(gcol, 2.0, 0.5), Vector3(P_GOD.x, 0.02, 0))
	omni(duel_root, Color(1, 0.95, 0.9), 1.4, 30.0, Vector3(0, 10, 4))
	me_node = build_machine()
	duel_root.add_child(me_node)
	me_node.position = P_ME
	god_node = build_god(kind, gcol)
	duel_root.add_child(god_node)
	god_node.position = P_GOD
	shield_me = sph(me_node, 2.3, mat(Color(0.5, 0.8, 1.0), 1.0, 0.25), Vector3.ZERO, 20)
	shield_god = sph(god_node, 2.6, mat(Color(0.9, 0.95, 1.0), 1.0, 0.25), Vector3.ZERO, 20)
	shield_me.visible = false
	shield_god.visible = false


func start_duel(adv: bool) -> void:
	var g: Dictionary = gods[war_god]
	var gcol := Color.html(str(g["col"]))
	var pw := player_power()
	var gp: float = g["power"]
	dpm = 140.0 + float(data["level"]) * 10.0 + sqrt(pw) * 3.0
	dgm = 140.0 + sqrt(gp) * 3.5
	dp = dpm
	dg = dgm
	if adv:
		dg = dgm * 0.75
	else:
		dp = dpm * 0.75
	en = 50.0
	g_en = 40.0
	p_shield = false
	g_shield = false
	shake_p = 0.0
	shake_g = 0.0
	turn = "player"
	log_lines.clear()
	build_duel_scene(gcol, String(g["kind"]))
	lbl_god.text = String(g["n"])
	lbl_god.add_theme_color_override("font_color", gcol.lightened(0.2))
	bar_god.add_theme_stylebox_override("fill", mk_style(gcol, 10, Color(0, 0, 0, 0)))
	add_log("بدأت مبارزة الآلهة! دورك الآن.")
	go("duel")
	upd_bars()
	set_duel_btns(true)


func upd_bars() -> void:
	bar_god.max_value = dgm
	bar_god.value = maxf(dg, 0.0)
	bar_me.max_value = dpm
	bar_me.value = maxf(dp, 0.0)
	bar_en.max_value = 100.0
	bar_en.value = en


func add_log(t: String) -> void:
	log_lines.append(t)
	while log_lines.size() > 2:
		log_lines.pop_front()
	duel_log.text = "\n".join(log_lines)


func set_duel_btns(on: bool) -> void:
	for b in duel_btns:
		b.disabled = not on


func upd_duel(dt: float) -> void:
	shake_p = maxf(0.0, shake_p - dt * 2.0)
	shake_g = maxf(0.0, shake_g - dt * 2.0)
	if me_node == null or god_node == null:
		return
	var mr: Array = me_node.get_meta("rings")
	for i in mr.size():
		var r: Node3D = mr[i]
		r.rotate_y(dt * (1.0 + 0.6 * float(i)))
		r.rotate_x(dt * 0.3 * float(i))
	var gr: Array = god_node.get_meta("rings")
	for i in gr.size():
		var r2: Node3D = gr[i]
		r2.rotate_y(dt * (0.8 + 0.8 * float(i)))
	var sj := Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1))
	me_node.position = P_ME + Vector3(0, 0.15 * sin(tm * 2.0), 0) + sj * shake_p * 0.35
	god_node.position = P_GOD + Vector3(0, 0.15 * sin(tm * 1.7), 0) + sj * shake_g * 0.35
	shield_me.visible = p_shield
	shield_god.visible = g_shield


func p_act(a: String) -> void:
	if turn != "player":
		return
	var wr := 1.0 + 0.12 * float(skill("wrath"))
	var base := randf_range(16.0, 26.0) + float(data["level"]) * 1.2 + sqrt(player_power()) * 0.25
	var d := 0.0
	var shoot := false
	var bigshot := false
	match a:
		"atk":
			d = base * wr
			shoot = true
			add_log("وجّهت ضربة كونية!")
		"big":
			if en < 40.0:
				toast("الطاقة غير كافية")
				return
			en -= 40.0
			d = base * 2.1 * wr
			shoot = true
			bigshot = true
			add_log("أطلقت انفجاراً نجمياً هائلاً!")
		"shield":
			p_shield = true
			add_log("رفعت درعاً إلهياً.")
			play("click")
		"heal":
			if en < 30.0:
				toast("الطاقة غير كافية")
				return
			en -= 30.0
			var h := 30.0 + 7.0 * float(skill("wisdom")) + dpm * 0.1
			dp = minf(dpm, dp + h)
			pop_text("+%d" % int(h), P_ME + Vector3(0, 1.8, 0), Color(0.5, 1, 0.6))
			add_log("استعدت جزءاً من قوتك.")
			play("heal")
	turn = "wait"
	set_duel_btns(false)
	upd_bars()
	if shoot:
		await fire_projectile(P_ME + Vector3(1.2, 0, 0), P_GOD, Color(0.6, 0.9, 1.0), bigshot)
		if g_shield:
			d *= 0.5
			g_shield = false
		dg -= d
		shake_g = 1.0
		pop_text("-%d" % int(d), P_GOD + Vector3(0, 2.0, 0), Color(1, 0.8, 0.4))
		burst3(P_GOD, Color(1, 0.8, 0.4), 16)
		play("big" if bigshot else "hit")
		upd_bars()
	if dg <= 0.0:
		duel_end(true)
		return
	await get_tree().create_timer(0.9).timeout
	if screen != "duel":
		return
	god_act()


func god_act() -> void:
	var g: Dictionary = gods[war_god]
	var kind: String = g["kind"]
	var gcol := Color.html(str(g["col"]))
	var gp := sqrt(float(g["power"]))
	g_en = minf(100.0, g_en + 25.0)
	en = minf(100.0, en + 25.0 + 5.0 * float(skill("wisdom")))
	var mv := "atk"
	match kind:
		"verdant":
			if dg < dgm * 0.5 and g_en >= 30.0 and randf() < 0.6:
				mv = "heal"
			elif randf() < 0.2:
				mv = "shield"
		"tyrant":
			if g_en >= 40.0 and randf() < 0.6:
				mv = "big"
		"void":
			var r := randf()
			if r < 0.3:
				mv = "drain"
			elif r < 0.45:
				mv = "curse"
	var gname: String = g["n"]
	var d := 0.0
	var shoot := false
	var bigshot := false
	match mv:
		"atk":
			d = randf_range(12.0, 20.0) + gp * 0.35
			shoot = true
			add_log("%s يهاجمك!" % gname)
		"big":
			g_en -= 40.0
			d = (randf_range(12.0, 20.0) + gp * 0.35) * 2.0
			shoot = true
			bigshot = true
			add_log("%s يطلق ضربة مدمرة!" % gname)
		"heal":
			g_en -= 30.0
			var h := 30.0 + gp * 0.8
			dg = minf(dgm, dg + h)
			pop_text("+%d" % int(h), P_GOD + Vector3(0, 2.0, 0), Color(0.5, 1, 0.6))
			add_log("%s يداوي نفسه." % gname)
			play("heal")
		"shield":
			g_shield = true
			add_log("%s يتحصّن بدرعه." % gname)
		"drain":
			d = 8.0 + gp * 0.15
			en = maxf(0.0, en - 30.0)
			dg = minf(dgm, dg + d * 0.8)
			shoot = true
			add_log("%s يمتص طاقتك!" % gname)
		"curse":
			d = 14.0 + gp * 0.3
			en = maxf(0.0, en - 15.0)
			shoot = true
			add_log("%s يلقي عليك لعنة الفراغ!" % gname)
	upd_bars()
	if shoot:
		await fire_projectile(P_GOD + Vector3(-1.4, 0, 0), P_ME, gcol, bigshot)
		if p_shield:
			d *= 0.4
			p_shield = false
		d *= (1.0 - 0.08 * float(skill("shield")))
		dp -= d
		shake_p = 1.0
		pop_text("-%d" % int(d), P_ME + Vector3(0, 1.8, 0), Color(1, 0.4, 0.4))
		burst3(P_ME, Color(1, 0.4, 0.4), 16)
		play("big" if bigshot else "hit")
		upd_bars()
	if dp <= 0.0:
		duel_end(false)
		return
	turn = "player"
	set_duel_btns(true)


func duel_end(won: bool) -> void:
	turn = "over"
	set_duel_btns(false)
	await get_tree().create_timer(0.8).timeout
	if won:
		victory()
	else:
		defeat()


func victory() -> void:
	var g: Dictionary = gods[war_god]
	var gain: float = float(g["power"]) * 0.5
	data["bonus"] = float(data["bonus"]) + gain
	var garr: Array = g["ents"]
	var map := {}
	for e in garr:
		map[int(e["id"])] = new_id()
	var ang := randf() * TAU
	var c := world_center(ents)
	var off := c + Vector3(cos(ang), 0, sin(ang)) * 35.0
	for e in garr:
		var ne: Dictionary = e.duplicate()
		ne["id"] = int(map[int(e["id"])])
		if ne.has("on"):
			if not map.has(int(e["on"])):
				continue
			ne["on"] = int(map[int(e["on"])])
		else:
			ne["x"] = off.x + float(e["x"])
			ne["z"] = off.z + float(e["z"])
		ents.append(ne)
	data["ents"] = ents
	data["wins"] = int(data["wins"]) + 1
	var old_name: String = g["n"]
	var gi := war_god
	add_xp(150 + int(sqrt(float(g["power"])) * 3.0))
	gods[gi] = make_god(int(g["i"]), int(data["wins"]))
	save_game()
	play("win")
	show_result("انتصرت!\nابتلعت عوالم %s وصار مصيره قوةً لك: +%d قوة إلهية.\nظهر إله أقوى يتحدى عرشك." % [old_name, int(gain)])


func defeat() -> void:
	add_xp(20)
	save_game()
	play("lose")
	show_result("هُزمت في المبارزة...\nلكن عوالمك ومخلوقاتك باقية. ازدد قوة وعد للانتقام.")


# ============================================================
#  التحديث
# ============================================================
func _process(dt: float) -> void:
	tm += dt
	update_camera(dt)
	animate(dt)
	update_fx(dt)
	if screen == "war":
		upd_war(dt)
	elif screen == "duel":
		upd_duel(dt)
